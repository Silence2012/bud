from handle import Handle
h = Handle()
print h.getMem()
print h.getMetric()
