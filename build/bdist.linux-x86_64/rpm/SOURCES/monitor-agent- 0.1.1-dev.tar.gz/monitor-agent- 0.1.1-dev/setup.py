from distutils.core import setup
exec(open('agent/version.py').read())
setup(
name = 'monitor-agent',
author = 'SimonSun',
author_email = '386488135@qq.com',
description = 'a monitor agent',
version = version,
packages = ['agent','web'],
)
